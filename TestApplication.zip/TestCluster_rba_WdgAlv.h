// ----------------------------------------------------------------------------
// COPYRIGHT RESERVED, 2007-2010, Robert Bosch GmbH. All rights reserved.  The
// reproduction, distribution and utilization of this document as well as the
// communication of its contents to others without explicit authorization is
// prohibited.  Offenders will be held liable for the payment of damages.  All
// rights reserved in the event of the grant of a patent, utility model or
// design.
// ----------------------------------------------------------------------------
//! \file
//! $ProjectName: d:/MKS_Data/Projects/BSW/Dev/Dev_BSW_PF_V850xx4/Dev_BSW_PF_V850xx4.pj $
//! \brief Configuration Header for the TestController
//!
//! $Source: $
//! $Author:  $
//! $Revision:  $
//! $Date: $
//! $State: $
//!
//!
// ----------------------------------------------------------------------------
// History:
//   $Log:   $
//
// ----------------------------------------------------------------------------
#ifndef TESTCLUSTER_NVM_H_
#define TESTCLUSTER_NVM_H_
/*--------------------------------------------------------------------------*/
/*- Include files -*/
/*--------------------------------------------------------------------------*/
#include "rba_CObt.h"
#include "rba_CBool.h"
#include "Std_Types.h"
#include "WdgM.h"
#include "Det_Priv.h"
#include "WdgM_Prv.h"
#include "rba_WdgAlv.h"
/*--------------------------------------------------------------------------*/
/*- Check if Compiler Switches (utilised in this file) are defined -*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*- exported symbolic constants -*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*- exported macros -*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*- exported data types -*/
/*--------------------------------------------------------------------------*/
/*--------------------------------------------------------------------------*/
/*- external object declarations -*/
/*--------------------------------------------------------------------------*/



extern Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu0_SetMode_return;
extern Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu1_SetMode_return;
extern Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu2_SetMode_return;
extern Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Safety_SetMode_return;

extern uint32 WdgIf_rba_IoExtCy327_SetResponse_xResponse_u32;

extern WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Safety_SetMode_Mode;
extern WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu0_SetMode_Mode;
extern WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu1_SetMode_Mode;
extern WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu2_SetMode_Mode;

extern boolean WdgIf_rba_IoExtCy327_RequestQuery_return;
extern boolean WdgIf_rba_IoExtCy327_SetRespTime_return;
extern boolean WdgIf_rba_IoExtCy327_GetRequest_return;
extern boolean WdgIf_rba_IoExtCy327_Transmit_return;
extern boolean WdgIf_rba_IoExtCy327_WD_Hdl_Invoked;
extern WdgIf_Rb_RequestType_tst WdgIf_rba_IoExtCy327_GetRequest_xRequest_ps;

extern uint32 WdgIf_rba_IoExtCy327_SetRespTime_tiResp_u32;
extern uint32 WdgIf_rba_IoExtCy327_SetResponse_xResponse_u32;

extern uint16 WdgIf_Wdg_6_IfxUc1Cpu0_SetTriggerCondition_TimoeOut;
extern uint16 WdgIf_Wdg_6_IfxUc1Cpu1_SetTriggerCondition_TimoeOut;
extern uint16 WdgIf_Wdg_6_IfxUc1Cpu2_SetTriggerCondition_TimoeOut;
extern uint16 WdgIf_Wdg_6_IfxUc1Safety_SetTriggerCondition_TimoeOut;

extern WdgM_ModeType rba_WdgAlv_WdgM_SetMode_Mode;
extern uint16 rba_WdgAlv_WdgM_SetMode_CallerID;
extern Std_ReturnType rba_WdgAlv_WdgM_SetMode_return;
extern WdgM_ModeType rba_WdgAlv_WdgM_GetMode_Mode;
extern Std_ReturnType rba_WdgAlv_WdgM_GetMode_return;
extern WdgM_SupervisedEntityIdType rba_WdgAlv_WdgM_CheckpointReached_SEID;
extern WdgM_CheckpointIdType rba_WdgAlv_WdgM_CheckpointReached_CheckpointID;
extern uint8 rba_WdgAlv_cp_counter;
extern uint8 global_access;

extern StatusType WdgM_GetElapsedCounterValue_return ;
extern TickType WdgM_GetElapsedCounterValue_Value;
extern TickType WdgM_GetElapsedCounterValue_ElapsedValue;

extern bool rba_WdgAlv_TestVar;


/*update these variables for SW Version check -- RUN5 */
#define WDGALV_SW_MAJOR_VERSION_LOCAL  (2)
#define WDGALV_SW_MINOR_VERSION_LOCAL  (0)
#define WDGALV_SW_PATCH_VERSION_LOCAL  (0)

/*--------------------------------------------------------------------------*/
/*- prototypes of exported functions -*/
/*--------------------------------------------------------------------------*/
 /** Action Functions **/
 void g_ActTest1_vd(uint8 Parameter);
 void g_ActTest2_vd(uint8 Parameter);
 void g_ActTest3_vd(uint8 Parameter);

 /*-----------------------------------TEST CASES ---------------------------------------*/

 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);

  /* Alive tasks configured for Alive supervision-  perl test cases
   * Note: IF mulitple intsances of BG, 1ms & 10ms are supported in rba_WdgAlv then increase the task number
   * example: g_TC_rba_WdgAlv_BG0_Task0_Proc_TC_02_03_ui8
   *          g_TC_rba_WdgAlv_BG0_Task1_Proc_TC_02_04_ui8
   *          g_TC_rba_WdgAlv_BG0_Task1_Proc_TC_02_51_ui8

   BG tasks */

 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);

 //1ms tasks
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);

  //10ms task
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);

  //Check for set mode functionality
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_SetMode_TC_05_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);
 /** Evaluation Functions **/
  rbaC_Obt_TestResult g_TC_rba_WdgAlv_SetMode_TC_05_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8);


 #endif /* TESTCLUSTER1_H_ */
 /*========================= EoF (TestCluster1.h) ================================*/
