// ----------------------------------------------------------------------------
// COPYRIGHT RESERVED, 2007-2010, Robert Bosch GmbH. All rights reserved.  The
// reproduction, distribution and utilization of this document as well as the
// communication of its contents to others without explicit authorization is
// prohibited.  Offenders will be held liable for the payment of damages.  All
// rights reserved in the event of the grant of a patent, utility model or
// design.
// ----------------------------------------------------------------------------
//! \file
//! $ProjectName: d:/MKS_Data/Projects/BSW/Dev/Dev_BSW_PF_V850xx4/Dev_BSW_PF_V850xx4.pj $
//! \brief Configuration Header for the TestController
//!
//! $Source: $
//! $Author:  $
//! $Revision:  $
//! $Date: $
//! $State: $
//
// ----------------------------------------------------------------------------
/** \defgroup ITF_TestCluster Example of a Test-Cluster
 *  @{
 */
/*--------------------------------------------------------------------------*/
/*- include files -*/
/*--------------------------------------------------------------------------*/
#include "TestCluster_rba_WdgAlv.h"

/*--------------------------------------------------------------------------*/
/*- Check if Compiler Switches (utilised in this file) are defined -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- local symbolic constants -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- local macros -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- local data types -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- local data -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- prototypes of local functions -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- global data objects -*/
/*--------------------------------------------------------------------------*/

WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Safety_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu0_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu1_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu2_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu3_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu4_SetMode_Mode;
WdgIf_ModeType WdgIf_Wdg_6_IfxUc1Cpu5_SetMode_Mode;


Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Safety_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu0_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu1_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu2_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu3_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu4_SetMode_return = E_OK;
Std_ReturnType 	WdgIf_Wdg_6_IfxUc1Cpu5_SetMode_return = E_OK;

boolean WdgIf_rba_IoExtCy327_RequestQuery_return;
boolean WdgIf_rba_IoExtCy327_SetRespTime_return;
boolean WdgIf_rba_IoExtCy327_GetRequest_return;
boolean WdgIf_rba_IoExtCy327_Transmit_return;
boolean WdgIf_rba_IoExtCy327_WD_Hdl_Invoked;
WdgIf_Rb_RequestType_tst WdgIf_rba_IoExtCy327_GetRequest_xRequest_ps;

uint32 WdgIf_rba_IoExtCy327_SetRespTime_tiResp_u32;
uint32 WdgIf_rba_IoExtCy327_SetResponse_xResponse_u32;

uint16 WdgIf_Wdg_6_IfxUc1Cpu0_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Cpu1_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Cpu2_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Cpu3_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Cpu4_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Cpu5_SetTriggerCondition_TimoeOut;
uint16 WdgIf_Wdg_6_IfxUc1Safety_SetTriggerCondition_TimoeOut;

WdgM_ModeType rba_WdgAlv_WdgM_SetMode_Mode;
uint16 rba_WdgAlv_WdgM_SetMode_CallerID;
Std_ReturnType rba_WdgAlv_WdgM_SetMode_return;
WdgM_ModeType rba_WdgAlv_WdgM_GetMode_Mode;
Std_ReturnType rba_WdgAlv_WdgM_GetMode_return;
WdgM_SupervisedEntityIdType rba_WdgAlv_WdgM_CheckpointReached_SEID;
WdgM_CheckpointIdType rba_WdgAlv_WdgM_CheckpointReached_CheckpointID;
uint8 rba_WdgAlv_cp_counter;
uint8 global_access;
StatusType WdgM_GetElapsedCounterValue_return = E_OK;
TickType WdgM_GetElapsedCounterValue_Value;
TickType WdgM_GetElapsedCounterValue_ElapsedValue;

/* Variable to change the state of SYC for test purpose */
bool rba_WdgAlv_TestVar = FALSE;


/*--------------------------------------------------------------------------*/
/*- definition of local functions -*/
/*--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*/
/*- public functions -*/
/*--------------------------------------------------------------------------*/


/*****************************************************************************
|-----------------------------------------------------------------------------
| F U N C T I O N D E S C R I P T I O N
|-----------------------------------------------------------------------------
*/
/*!
   \public

   \brief

   \param    void

   \return    enum

  $Author:  $

*****************************************************************************/
void g_ActTest1_vd(unsigned char Parameter)
{

}
/***********************************************  TEST_CASE_DEFINITION *************************************************/
/****************  rba_WdgAlv_GetVersionInfo Test Cases **********************/

/* DET Check */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	Det_Errors[0].moduleId = 0;
	Det_Errors[0].instanceId = 0;
	Det_Errors[0].apiId = 0;
	Det_Errors[0].errorId = 0;

	/* Passing NULL pointer, will result into DET error */
	rba_WdgAlv_GetVersionInfo((Std_VersionInfoType*)NULL_PTR);

			     if (( Det_Errors[0].moduleId == RBA_WDGALV_MODULE_ID) &&
			         ( Det_Errors[0].instanceId == RBA_WDGALV_INSTANCE_ID) &&
			         ( Det_Errors[0].apiId == RBA_WDGALV_GETVERSIONINFO_APIID)&&
			         ( Det_Errors[0].errorId == RBA_WDGALV_E_INV_POINTER)
			        )
	              {
	    	          return rbaCObt_TCPassed_e;
	               }
	              else
	               {
	    	          return rbaCObt_TCFailed_e;
	               }

 }

/* rba_WdgAlv_GetVersionInfo Successful Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	    Std_VersionInfoType VersionInfo;
	    VersionInfo.vendorID = 0;
	    VersionInfo.moduleID = 0;
	    VersionInfo.sw_major_version = 0;
	    VersionInfo.sw_minor_version = 0;
	    VersionInfo.sw_patch_version = 0;
		rba_WdgAlv_GetVersionInfo(&VersionInfo);

		if (( VersionInfo.vendorID == RBA_WDGALV_VENDOR_ID) &&
			( VersionInfo.moduleID == RBA_WDGALV_MODULE_ID) &&
			( VersionInfo.sw_major_version == RBA_WDGALV_SW_MAJOR_VERSION) &&
			( VersionInfo.sw_minor_version == RBA_WDGALV_SW_MINOR_VERSION)&&
			( VersionInfo.sw_patch_version == RBA_WDGALV_SW_PATCH_VERSION))

	              {
	    	          return rbaCObt_TCPassed_e;
	               }
	              else
	               {
	    	          return rbaCObt_TCFailed_e;
	               }

 }

/* rba_WdgDeadline Software release VersionInfo check */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_GetVersionInfo_TC_01_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
        Std_VersionInfoType VersionInfo;
        VersionInfo.vendorID = 0;
        VersionInfo.moduleID = 0;
        VersionInfo.sw_major_version = 0;
        VersionInfo.sw_minor_version = 0;
        VersionInfo.sw_patch_version = 0;
        rba_WdgAlv_GetVersionInfo(&VersionInfo);

        if ((VersionInfo.sw_major_version == WDGALV_SW_MAJOR_VERSION_LOCAL) &&
            ( VersionInfo.sw_minor_version == WDGALV_SW_MINOR_VERSION_LOCAL)&&
            ( VersionInfo.sw_patch_version == WDGALV_SW_PATCH_VERSION_LOCAL))

                  {
                      return rbaCObt_TCPassed_e;
                   }
                  else
                   {
                      return rbaCObt_TCFailed_e;
                   }

 }


/****************** rba_WdgAlv - BG TASK  **************/

/* DET Check */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_DEACTIVATED;
	Det_Errors[0].moduleId = 0;
	Det_Errors[0].instanceId = 0;
	Det_Errors[0].apiId = 0;
	Det_Errors[0].errorId = 0;

	rba_WdgAlv_Bg_SEID0_Proc();
	 if (( Det_Errors[0].moduleId == RBA_WDGALV_MODULE_ID) &&
		 ( Det_Errors[0].instanceId == RBA_WDGALV_INSTANCE_ID) &&
	     ( Det_Errors[0].apiId == RBA_WDGALV_BG_SEID0_PROC_APIID)&&
         ( Det_Errors[0].errorId == RBA_WDGALV_E_WDGM_NOT_INIT)
		 )
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }

}

/* rba_WdgAlv_Bg_SEID0_Proc Successful Operation */
 rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_OK;
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[0].OldLocalStatus = WDGM_LOCAL_STATUS_OK;

	rba_WdgAlv_Bg_SEID0_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID == WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Alive0_Bg
	&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Alive0_Bg)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}

/* rba_WdgAlv_Bg_SEID0_Proc failure Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_BG_Task0_Proc_TC_02_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[0].OldLocalStatus = WDGM_LOCAL_STATUS_DEACTIVATED;

	/* Since SE is in de-activated state, checkpoint reached will not be called */
	rba_WdgAlv_Bg_SEID0_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID == WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy
		&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}



/****************** rba_WdgAlv - 1MS TASK  **************/

/* DET Check */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_DEACTIVATED;
	Det_Errors[0].moduleId = 0;
	Det_Errors[0].instanceId = 0;
	Det_Errors[0].apiId = 0;
	Det_Errors[0].errorId = 0;

	rba_WdgAlv_1ms_SEID1_Proc();
	 if (( Det_Errors[0].moduleId == RBA_WDGALV_MODULE_ID) &&
		 ( Det_Errors[0].instanceId == RBA_WDGALV_INSTANCE_ID) &&
	     ( Det_Errors[0].apiId == RBA_WDGALV_1MS_SEID1_PROC_APIID)&&
         ( Det_Errors[0].errorId == RBA_WDGALV_E_WDGM_NOT_INIT)
		 )
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }

}

/* rba_WdgAlv_1ms_SEID1_Proc Successful Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_OK;
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[1].OldLocalStatus = WDGM_LOCAL_STATUS_OK;

	rba_WdgAlv_1ms_SEID1_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID==WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Alive1_1ms
		&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Alive1_1ms)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}

/* rba_WdgAlv_1ms_SEID1_Proc failure Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_1ms_Task0_Proc_TC_03_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[1].OldLocalStatus = WDGM_LOCAL_STATUS_DEACTIVATED;

	/* Since SE is in deactivated state, checkpoint reached will not be called */
	rba_WdgAlv_1ms_SEID1_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID==WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy
				&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}


/****************** rba_WdgAlv - 10MS TASK  **************/

/* DET Check */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_DEACTIVATED;
	Det_Errors[0].moduleId = 0;
	Det_Errors[0].instanceId = 0;
	Det_Errors[0].apiId = 0;
	Det_Errors[0].errorId = 0;

	rba_WdgAlv_10ms_SEID2_Proc();
	 if (( Det_Errors[0].moduleId == RBA_WDGALV_MODULE_ID) &&
		 ( Det_Errors[0].instanceId == RBA_WDGALV_INSTANCE_ID) &&
	     ( Det_Errors[0].apiId == RBA_WDGALV_10MS_SEID2_PROC_APIID)&&
         ( Det_Errors[0].errorId == RBA_WDGALV_E_WDGM_NOT_INIT)
		 )
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }

}

/* rba_WdgAlv_10ms_SEID2_Proc Successful Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_OK;
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[2].OldLocalStatus = WDGM_LOCAL_STATUS_OK;

	rba_WdgAlv_10ms_SEID2_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID==WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Alive2_10ms
		&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Alive2_10ms)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}

/* rba_WdgAlv_10ms_SEID2_Proc failure Operation */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_10ms_Task0_Proc_TC_04_03_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	rba_WdgAlv_WdgM_CheckpointReached_SEID=WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy;
	rba_WdgAlv_WdgM_CheckpointReached_CheckpointID = WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy;
	WdgM_SupervisedEntityDyn[2].OldLocalStatus = WDGM_LOCAL_STATUS_DEACTIVATED;

	/* Since SE is in deactivated state, checkpoint reached will not be called */
	rba_WdgAlv_10ms_SEID2_Proc();
	 if (rba_WdgAlv_WdgM_CheckpointReached_SEID ==WdgMConf_WdgMSupervisedEntity_WdgMSupervisedEntity_Dummy
		&& rba_WdgAlv_WdgM_CheckpointReached_CheckpointID == WdgMConf_WdgMCheckpoint_SE_WdgMCheckpoint_Dummy)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }
}





/****************** rba_WdgAlv - SETMODE  **************/

/* rba_WdgAlv_SetMode Successful Operation - Mode Change from WdgMConf_WdgMMode_Initial to
   WdgMConf_WdgMMode_Run  */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_SetMode_TC_05_01_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_ModeType Mode;

	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_OK;
	WdgM_Mode = WdgMConf_WdgMMode_Initial;
	rba_WdgAlv_TestVar = FALSE;

	rba_WdgAlv_SetMode();
	WdgM_GetMode(&Mode);

	 if (Mode == WdgMConf_WdgMMode_Run)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }

}

/* rba_WdgAlv_SetMode Successful Operation - Mode Change from WdgMConf_WdgMMode_Run to
   WdgMConf_WdgMMode_Run  */
rbaC_Obt_TestResult g_TC_rba_WdgAlv_SetMode_TC_05_02_ui8(uint8 rbaC_Obt_I_IteratorTestBuffer_u8)
{
	WdgM_ModeType Mode;

	WdgM_GlobalStatus = WDGM_GLOBAL_STATUS_OK;
	WdgM_Mode = WdgMConf_WdgMMode_Run;
	rba_WdgAlv_TestVar = FALSE;

	rba_WdgAlv_SetMode();
	WdgM_GetMode(&Mode);

	 if (Mode == WdgMConf_WdgMMode_Run)
		   {
		      return rbaCObt_TCPassed_e;
		   }
	  else
		   {
		      return rbaCObt_TCFailed_e;
		   }

}


/*
*  @}
*/
/*=========================================================*/



